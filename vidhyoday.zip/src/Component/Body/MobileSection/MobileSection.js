import React from 'react'
import { Box, Button, Card, CardActions, CardContent, CardMedia, Grid, Typography } from '@mui/material';
import { Container } from "@mui/system";
import { styled } from '@mui/material/styles';
import phoneImg from './Group86sfd.png';
import image3 from './img2.jpeg';
import image4 from './image4.png';
import image5 from './imag4.jpeg';

function MobileSection() {

    const CustomContainer = styled(Container)(({ theme }) => ({
        // display: "flex",
        justifyContent: "space-between",
        marginTop: '60px',
        [theme.breakpoints.down("md")]: {
            flexDirection: "column",
            alignItems: "center",
            textAlign: "center",
            marginBottom: theme.spacing(4),
        },
    }));
    const CustomBox = styled(Box)(({ theme }) => ({
        // display: "flex",
        // justifyContent: "center",
        gap: theme.spacing(5),
        marginTop: theme.spacing(3),
        [theme.breakpoints.down("md")]: {
            // flexDirection: "column",
            alignItems: "center",
            // textAlign: "center",
        },
    }));

    return (
        <CustomContainer>
            <CustomBox>
                <Box sx={{
                    width: '100%',
                    display: 'flex',
                    justifyContent: 'space-around'
                }}>
                    <Grid container
                        sx={{
                            // backgroundImage: `url(${backgroundImage})`,
                            // backgroundSize: 'cover',
                            // backgroundPosition: 'center',
                        }}
                    >
                        <Grid item xs={12} md={6} 
                        sx={{
                            background: 'radial-gradient(125.59% 52.59% at 91% 65%, rgba(241, 255, 157, 0.624) 0%, rgba(254, 157, 250, 0) 83.33%)'
                        }}>
                            <img
                                style={{
                                    width: '100%',
                                    marginTop: ['30px', '85px'],
                                    marginLeft: ['10px', '70px'],
                                    maxWidth: '100%',
                                    height: 'auto',
                                    overflow: 'hidden'
                                }}
                                src={phoneImg}
                            />
                        </Grid>
                        <Grid item xs={12} md={6} sx={{ width: '100%' }}>
                            <Box sx={{ width: '100%', float: 'right' }}>
                                <Typography
                                    sx={{
                                        font: 'Roboto',
                                        fontSize: ['35px', '45px', '55px'],
                                        fontWeight: 'bold',
                                        marginBottom: '28px',
                                        lineHeight: ['42px', '48px', '58px'],
                                    }}
                                >
                                    Supercharge Your Learning
                                </Typography>
                                <Typography sx={{ font: 'Roboto', fontSize: '20px', lineHeight: '24px' }}>
                                    Download our app now and gain instant access to exclusive study materials, personalized notifications, and real-time progress tracking. Take control of your educational journey and unlock a world of convenience and success in just a few taps. Don't miss out, download now!
                                </Typography>
                                <Box sx={{ width: '100%', display: 'flex', justifyContent: 'space-around', marginTop: '1rem', overflow: 'hidden' }}>
                                    <Grid container spacing={2}>
                                        <Grid item xs={4}>
                                            <img
                                                style={{
                                                    aspectRatio: '181/82',
                                                    width: '100%',
                                                    maxWidth: '100%',
                                                    height: 'auto',
                                                }} src={image3} />
                                        </Grid>
                                        <Grid item xs={4}>
                                            <img style={{
                                                aspectRatio: '181/82',
                                                width: '100%',
                                                maxWidth: '100%',
                                                height: 'auto',
                                            }} src={image4} />
                                        </Grid>
                                        <Grid item xs={4}>
                                            <img style={{
                                                aspectRatio: '181/82',
                                                width: '100%',
                                                maxWidth: '100%',
                                                height: 'auto',
                                            }} src={image5} />
                                        </Grid>
                                    </Grid>
                                </Box>
                            </Box>
                        </Grid>
                    </Grid>

                </Box>
            </CustomBox>
        </CustomContainer>
    )
}

export default MobileSection