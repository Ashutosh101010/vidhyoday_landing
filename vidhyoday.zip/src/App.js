import { BrowserRouter  } from 'react-router-dom';

import Body from './Component/Body/Body';
import Header from './Component/NavBar/Header';
import Footer from './Component/Footer/Footer';
import VideoPlay from './Component/Body/VideoPlay/VideoPlay';
function App() {

  return (
    <>
     <BrowserRouter> 
     <VideoPlay/> 
    <Header sticky={true}/>
    <Body/>
    <Footer/>
    </BrowserRouter>
    </>
  )
}

export default App